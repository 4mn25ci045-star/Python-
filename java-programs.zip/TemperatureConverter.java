import java.util.Scanner;
public class TemperatureConverter { public static void main(String[] args) { double celsius = new Scanner(System.in).nextDouble(); System.out.println("Fahrenheit: " + (celsius * 9 / 5 + 32)); } }
