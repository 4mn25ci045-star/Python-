import java.util.Scanner;
public class Factorial { public static void main(String[] args) { Scanner s = new Scanner(System.in); int n = s.nextInt(); long result = 1; for (int i = 2; i <= n; i++) result *= i; System.out.println("Factorial: " + result); } }
