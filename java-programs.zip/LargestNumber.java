import java.util.Scanner;
public class LargestNumber { public static void main(String[] args) { Scanner s = new Scanner(System.in); int n = s.nextInt(); double largest = s.nextDouble(); for (int i = 1; i < n; i++) largest = Math.max(largest, s.nextDouble()); System.out.println("Largest: " + largest); } }
