import java.util.Scanner;
public class ReverseString { public static void main(String[] args) { String text = new Scanner(System.in).nextLine(); System.out.println("Reversed: " + new StringBuilder(text).reverse()); } }
