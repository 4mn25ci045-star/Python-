import java.util.Scanner;

public class PrimeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a positive integer: ");
        int number = scanner.nextInt();
        boolean isPrime = number >= 2;

        for (int divisor = 2; divisor * divisor <= number && isPrime; divisor++) {
            if (number % divisor == 0) isPrime = false;
        }

        System.out.println(number + (isPrime ? " is prime." : " is not prime."));
        scanner.close();
    }
}
