import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first number: ");
        double first = scanner.nextDouble();
        System.out.print("Enter operator (+, -, *, /): ");
        char operator = scanner.next().charAt(0);
        System.out.print("Enter second number: ");
        double second = scanner.nextDouble();

        if (operator == '/' && second == 0) {
            System.out.println("Cannot divide by zero.");
        } else {
            double result = switch (operator) {
                case '+' -> first + second;
                case '-' -> first - second;
                case '*' -> first * second;
                case '/' -> first / second;
                default -> Double.NaN;
            };
            System.out.println(Double.isNaN(result) ? "Invalid operator." : "Result: " + result);
        }
        scanner.close();
    }
}
