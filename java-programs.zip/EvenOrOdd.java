import java.util.Scanner;
public class EvenOrOdd { public static void main(String[] args) { int number = new Scanner(System.in).nextInt(); System.out.println(number % 2 == 0 ? "Even" : "Odd"); } }
