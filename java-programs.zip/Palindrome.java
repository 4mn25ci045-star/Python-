import java.util.Scanner;
public class Palindrome { public static void main(String[] args) { String text = new Scanner(System.in).nextLine().replace(" ", "").toLowerCase(); String reverse = new StringBuilder(text).reverse().toString(); System.out.println(text.equals(reverse) ? "Palindrome" : "Not a palindrome"); } }
