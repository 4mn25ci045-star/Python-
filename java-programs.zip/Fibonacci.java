import java.util.Scanner;
public class Fibonacci { public static void main(String[] args) { Scanner s = new Scanner(System.in); int n = s.nextInt(); long a = 0, b = 1; for (int i = 0; i < n; i++) { System.out.print(a + " "); long next = a + b; a = b; b = next; } } }
