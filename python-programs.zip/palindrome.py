text = input("Enter text: ")
cleaned = text.lower().replace(" ", "")
print("Palindrome" if cleaned == cleaned[::-1] else "Not a palindrome")
