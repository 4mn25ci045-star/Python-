"""A simple command-line calculator."""

first = float(input("Enter first number: "))
operator = input("Enter operator (+, -, *, /): ")
second = float(input("Enter second number: "))

if operator == "+":
    result = first + second
elif operator == "-":
    result = first - second
elif operator == "*":
    result = first * second
elif operator == "/":
    result = "Cannot divide by zero" if second == 0 else first / second
else:
    result = "Invalid operator"

print("Result:", result)
