number = int(input("Enter a non-negative integer: "))
result = 1
for value in range(2, number + 1):
    result *= value
print("Factorial:", result)
