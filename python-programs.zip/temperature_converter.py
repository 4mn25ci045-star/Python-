celsius = float(input("Enter temperature in Celsius: "))
print("Fahrenheit:", (celsius * 9 / 5) + 32)
