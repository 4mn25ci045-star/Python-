"""Print a welcome message."""

print("Hello, World!")
