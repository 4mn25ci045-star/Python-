numbers = list(map(float, input("Enter numbers separated by spaces: ").split()))
print("Largest:", max(numbers))
